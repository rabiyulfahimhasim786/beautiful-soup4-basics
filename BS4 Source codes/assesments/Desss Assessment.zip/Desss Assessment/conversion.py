def encrypt(text,s):
	output = ""

	# traverse text
	for i in range(len(text)):
		char = text[i]

		# Encrypt uppercase characters
		if (char.isupper()):
			output += chr((ord(char) + s-65) % 26 + 65)

		# Encrypt lowercase characters
		else:
			output += chr((ord(char) + s - 97) % 26 + 97)

	return output

#check the above function
text = "ATTACKATONCE"
s = 4
print ("Text : " + text)
print ("Shift : " + str(s))
print ("Cipher: " + encrypt(text,s))
