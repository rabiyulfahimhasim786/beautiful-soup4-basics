# Store input numbers:  
num1 = input('Enter first number: ')
num2 = input('Enter second number: ')  
num3 = input('Enter third number: ')
num4 = input('Enter fourth number: ') 
num5 = input('Enter fifth number: ') 
num6 = input('Enter sixth number: ') 
num7 = input('Enter seventh number: ')   
# Add two numbers  
sum = float(num1) + float(num2) + float(num3)  + float(num4) - float(num5) * float(num6) % float(num7)
print('The output of the given numbers {4}'.format(num1, num2, num3, num4, sum))  
print(sum)