# Import Module
import cffi
from flask_sqlalchemy import SQLAlchemy
from jinja2 import escape
from flask import Flask, request, redirect, render_template, url_for, jsonify, make_response, flash, redirect,url_for,session,logging,request
#from matplotlib.pyplot import xlim
import yfinance as yf
import requests
from bs4 import BeautifulSoup
import pandas as pd
import json
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from df2gspread import df2gspread as d2g
import requests
#import schedule
import pandas as pd
#import time
import optparse
import os
#from fake_useragent import UserAgent
import pyuser_agent
from decimal import Decimal
import json
import schedule
import time
from datetime import datetime, timedelta
import ftplib
app = Flask('app')

@app.route('/')
def hello_world():
  # Fill Required Information
  #HOSTNAME = "74.208.51.69"
  #USERNAME = "stockftpusr"
  #PASSWORD = "T11wz8w_"
  #Connect FTP Server
  #ftp_server = ftplib.FTP(HOSTNAME, USERNAME, PASSWORD)
  #ftp_server.login()
  # force UTF-8 encoding
  #ftp_server.encoding = "utf-8"
  #ftp_server.cwd changing required directory
  #ftp_server.quit()
  return '<h1>Hello, World!</h1>'

@app.route('/gainerstables', methods=["GET", "POST"])
def gainerstables():
    # converting csv to html
    data = pd.read_csv('yahoo_gainers1.csv')
    return render_template('gainerstable.html', tables=[data.to_html()], titles=[''])


@app.route('/loserstables', methods=["GET", "POST"])
def loserstables():
    # converting csv to html
    data = pd.read_csv('yahoo_losers1.csv')
    return render_template('loserstable.html', tables=[data.to_html()], titles=[''])

@app.route('/mostactivetables', methods=["GET", "POST"])
def mostactivetables():
    # converting csv to html
    data = pd.read_csv('yahoo_most_active1.csv')
    return render_template('mostactivetable.html', tables=[data.to_html()], titles=[''])

@app.route('/trendingtables', methods=["GET", "POST"])
def trendingtables():
    # converting csv to html
    data = pd.read_csv('yahoo_trending1.csv')
    return render_template('trendingtable.html', tables=[data.to_html()], titles=[''])

@app.route("/gainersfile", methods =["GET", "POST"])
def gainersdatas():
    if request.method == "POST":
        if True:
            #url = request.form['text']
            # getting input with name = fname in HTML form
            ua = pyuser_agent.UA()
            #ua = UserAgent()
            url = request.form['namee']
            #gainers = form(name = url)
            #db.session.add(gainers)
            #db.session.commit()
            #url = 'https://finance.yahoo.com/gainers?count=100&offset=0'
            headers = {'User-Agent': ua.random }
            html = requests.get(url, headers=headers).content
        #html = requests.get(url).content
            soup = BeautifulSoup(html, 'lxml')
            ac = soup.find_all('a', attrs={'data-test': 'quoteLink'})
            bc = soup.find_all('td', attrs={'aria-label': 'Name'})
            cc = soup.find_all('td', attrs={'aria-label': 'Price (Intraday)'})
            dc = soup.find_all('td', attrs={'aria-label': 'Change'})
            ec = soup.find_all('td', attrs={'aria-label': '% Change'})
            fc = soup.find_all('td', attrs={'aria-label': 'Volume'})
            gc = soup.find_all('td', attrs={'aria-label': 'Avg Vol (3 month)'})
            hc = soup.find_all('td', attrs={'aria-label': 'Market Cap'})
            ic = soup.find_all('td', attrs={'aria-label': 'PE Ratio (TTM)'})
  

            ac_ = []
            bc_ = []
            cc_ = []
            dc_ = []
            ec_ = []
            fc_ = []
            gc_ = []
            hc_ = []
            ic_ = []
            for title in ac:
                ac_.append(title.text.strip())
            for title in bc:
                bc_.append(title.text.strip())
            for title in cc:
                cc_.append(title.text.strip())
            for title in dc:
                dc_.append(title.text.strip())
            for title in ec:
                ec_.append(title.text.strip())
            for title in fc:
                fc_.append(title.text.strip())
            for title in gc:
                gc_.append(title.text.strip())
            for title in hc:
                hc_.append(title.text.strip())
            for title in ic:
                ic_.append(title.text.strip())
            # dataframe Name and Age columns
    #df = pd.DataFrame({'Symbol': ac_, 'Name': bc_, 'Price': cc_, 'Change': dc_, 'Change %': ec_, 'Volume': fc_, 'Avg volume': gc_, 'Market cap': hc_, 'Ration': ic_,})
            dict = {'Symbol': ac_, 'Name': bc_, 'Price': cc_, 'Change': dc_, 'Change %': ec_, 'Volume': fc_, 'Avg volume': gc_, 'Market cap': hc_, 'Ration': ic_,}
            df = pd.DataFrame(dict)
             # saving the dataframe
            df.to_csv('yahoo_gainers1.csv')
            # Fill Required Information
            HOSTNAME = "74.208.51.69"
            USERNAME = "stockftpusr"
            PASSWORD = "T11wz8w_"
            #Connect FTP Server
            ftp_server = ftplib.FTP(HOSTNAME, USERNAME, PASSWORD)
            #ftp_server.login()
            # force UTF-8 encoding
            ftp_server.encoding = "utf-8"
            #ftp_server.cwd changing required directory
            ftp_server.cwd('/assets/yahoo/yahoo_gainers/')
            # Enter File Name with Extension
            filename = "yahoo_gainers1.csv"
            # Read file in binary mode
            with open(filename, "rb") as file:
              # Command for Uploading the file "STOR filename"
              ftp_server.storbinary(f"STOR {filename}", file) 
            # Get list of files
            ftp_server.dir()
            # Close the Connection
            ftp_server.quit()
        return 'ok'
    return render_template("gainersfile.html")
  # dataframe Name and Age columns
            #df = pd.DataFrame({'Symbol': ac_, 'Name': bc_, 'Price': cc_, 'Change': dc_, 'Change %': ec_, 'Volume': fc_, 'Avg volume': gc_, 'Market cap': hc_, 'Ration': ic_,})
            #scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive','https://www.googleapis.com/auth/drive.file','https://www.googleapis.com/auth/spreadsheets']
            #creds = ServiceAccountCredentials.from_json_keyfile_name('yahoo_gainers.json', scope)
            #client = gspread.authorize(creds)
          #  spreadsheet_key = '1m-mrYAqoUvm5OTN1dq8rRr3sLtDuEh8bxVzQCYi2q44'
          #  wks_name = 'Sheet1'
           # cell_of_start_df = 'A2'
           # d2g.upload(df,
           # spreadsheet_key,
           # wks_name,
           # credentials=creds,
           # col_names=False,
           # row_names=False,
           # start_cell = cell_of_start_df,
           # clean=False)
            #requests.get("https://stocks.desss-portfolio.com/yahoo/yahoo_gainers")
          #  return schedule.CancelJob
           # return 'ok'
    #schedule.every(1).seconds.do(gainersdatas)
    #while True:
    #    schedule.run_pending()
    #    if not schedule.jobs:
    #        break
    #    time.sleep(1)
    #return render_template("gainers4.html")
    #return make_response(render_template('gainers4.html'),200)
    #else:
       # return render_template("gainers4.html")
#
  

@app.route("/losersfile", methods =["GET", "POST"])
def losersdatasfile():
    if request.method == "POST":
        if True:
            #url = request.form['text']
            # getting input with name = fname in HTML form
            ua = pyuser_agent.UA()
            #ua = UserAgent()
            url = request.form['namee']
            #losers = form(name = url)
            #db.session.add(losers)
            #db.session.commit()
            #url = 'https://finance.yahoo.com/gainers?count=100&offset=0'
            headers = {'User-Agent': ua.random }
            html = requests.get(url, headers=headers).content
        #html = requests.get(url).content
            soup = BeautifulSoup(html, 'lxml')
            ar = soup.find_all('a', attrs={'data-test': 'quoteLink'})
            br = soup.find_all('td', attrs={'aria-label': 'Name'})
            cr = soup.find_all('td', attrs={'aria-label': 'Price (Intraday)'})
            dr = soup.find_all('td', attrs={'aria-label': 'Change'})
            er = soup.find_all('td', attrs={'aria-label': '% Change'})
            fr = soup.find_all('td', attrs={'aria-label': 'Volume'})
            gr = soup.find_all('td', attrs={'aria-label': 'Avg Vol (3 month)'})
            hr = soup.find_all('td', attrs={'aria-label': 'Market Cap'})
            ir = soup.find_all('td', attrs={'aria-label': 'PE Ratio (TTM)'})
  

            ar_ = []
            br_ = []
            cr_ = []
            dr_ = []
            er_ = []
            fr_ = []
            gr_ = []
            hr_ = []
            ir_ = []
            for title in ar:
                ar_.append(title.text.strip())
            for title in br:
                br_.append(title.text.strip())
            for title in cr:
                cr_.append(title.text.strip())
            for title in dr:
                dr_.append(title.text.strip())
            for title in er:
                er_.append(title.text.strip())
            for title in fr:
                fr_.append(title.text.strip())
            for title in gr:
                gr_.append(title.text.strip())
            for title in hr:
                hr_.append(title.text.strip())
            for title in ir:
                ir_.append(title.text.strip())
  # dataframe Name and Age columns
            dict = {'Symbol': ar_, 'Name': br_, 'Price': cr_, 'Change': dr_, 'Change %': er_, 'Volume': fr_, 'Avg volume': gr_, 'Market cap': hr_, 'Ration': ir_,}
            df = pd.DataFrame(dict)
             # saving the dataframe
            df.to_csv('yahoo_losers1.csv')
            # Fill Required Information
            HOSTNAME = "74.208.51.69"
            USERNAME = "stockftpusr"
            PASSWORD = "T11wz8w_"
            #Connect FTP Server
            ftp_server = ftplib.FTP(HOSTNAME, USERNAME, PASSWORD)
            #ftp_server.login()
            # force UTF-8 encoding
            ftp_server.encoding = "utf-8"
            #ftp_server.cwd changing required directory
            ftp_server.cwd('/assets/yahoo/yahoo_losers/')
            # Enter File Name with Extension
            filename = "yahoo_losers1.csv"
            # Read file in binary mode
            with open(filename, "rb") as file:
              # Command for Uploading the file "STOR filename"
              ftp_server.storbinary(f"STOR {filename}", file) 
            # Get list of files
            ftp_server.dir()
            # Close the Connection
            ftp_server.quit()
          #losersfile
        return 'ok'
    return render_template("losersfile.html")
            #df = pd.DataFrame({'Symbol': ar_, 'Name': br_, 'Price': cr_, 'Change': dr_, 'Change %': er_, 'Volume': fr_, 'Avg volume': gr_, 'Market cap': hr_, 'Ration': ir_,})
            #scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive','https://www.googleapis.com/auth/drive.file','https://www.googleapis.com/auth/spreadsheets']
           # creds = ServiceAccountCredentials.from_json_keyfile_name('yahoo_losers.json', scope)
            #client = gspread.authorize(creds)
            #spreadsheet_key = '1X7APg9YH6ndu2lEhYDjMrWGwE1mQZlIh3G-XbzV_8zA'
            #wks_name = 'Sheet1'
            #cell_of_start_df = 'A2'
            #d2g.upload(df,
            #spreadsheet_key,
            #wks_name,
            #credentials=creds,
            #col_names=False,
            #row_names=False,
            #start_cell = cell_of_start_df,
            #clean=False)
            #requests.get("https://stocks.desss-portfolio.com/yahoo/yahoo_losers")
          #  return schedule.CancelJob
            
            #return 'ok'
    #schedule.every(1).seconds.do(gainersdatas)
    #while True:
    #    schedule.run_pending()
    #    if not schedule.jobs:
    #        break
    #    time.sleep(1)
    #return render_template("losersfile.html")
    #return make_response(render_template('gainers4.html'),200)
    #else:
       # return render_template("gainers4.html")

#


@app.route("/mostactivefile", methods =["GET", "POST"])
def mostactivefile():
    if request.method == "POST":
        if True:
            #url = request.form['text']
            # getting input with name = fname in HTML form
            ua = pyuser_agent.UA()
            #ua = UserAgent()
            url = request.form['namee']
            #losers = form(name = url)
            #db.session.add(losers)
            #db.session.commit()
            #url = 'https://finance.yahoo.com/gainers?count=100&offset=0'
            headers = {'User-Agent': ua.random }
            html = requests.get(url, headers=headers).content
        #html = requests.get(url).content
            soup = BeautifulSoup(html, 'lxml')
            at = soup.find_all('a', attrs={'data-test': 'quoteLink'})
            bt = soup.find_all('td', attrs={'aria-label': 'Name'})
            ct = soup.find_all('td', attrs={'aria-label': 'Price (Intraday)'})
            dt = soup.find_all('td', attrs={'aria-label': 'Change'})
            et = soup.find_all('td', attrs={'aria-label': '% Change'})
            ft = soup.find_all('td', attrs={'aria-label': 'Volume'})
            gt = soup.find_all('td', attrs={'aria-label': 'Avg Vol (3 month)'})
            ht = soup.find_all('td', attrs={'aria-label': 'Market Cap'})
            it = soup.find_all('td', attrs={'aria-label': 'PE Ratio (TTM)'})
  

            at_ = []
            bt_ = []
            ct_ = []
            dt_ = []
            et_ = []
            ft_ = []
            gt_ = []
            ht_ = []
            it_ = []
            for title in at:
                at_.append(title.text.strip())
            for title in bt:
                bt_.append(title.text.strip())
            for title in ct:
                ct_.append(title.text.strip())
            for title in dt:
                dt_.append(title.text.strip())
            for title in et:
                et_.append(title.text.strip())
            for title in ft:
                ft_.append(title.text.strip())
            for title in gt:
                gt_.append(title.text.strip())
            for title in ht:
                ht_.append(title.text.strip())
            for title in it:
                it_.append(title.text.strip())
  # dataframe Name and Age columns

            dict = {'Symbol': at_, 'Name': bt_, 'Price': ct_, 'Change': dt_, 'Change %': et_, 'Volume': ft_, 'Avg volume': gt_, 'Market cap': ht_, 'Ration': it_,}
            df = pd.DataFrame(dict)
             # saving the dataframe
            df.to_csv('yahoo_most_active1.csv')
            # Fill Required Information
            HOSTNAME = "74.208.51.69"
            USERNAME = "stockftpusr"
            PASSWORD = "T11wz8w_"
            #Connect FTP Server
            ftp_server = ftplib.FTP(HOSTNAME, USERNAME, PASSWORD)
            #ftp_server.login()
            # force UTF-8 encoding
            ftp_server.encoding = "utf-8"
            #ftp_server.cwd changing required directory
            ftp_server.cwd('/assets/yahoo/most_active/')
            # Enter File Name with Extension
            filename = "yahoo_most_active1.csv"
            # Read file in binary mode
            with open(filename, "rb") as file:
              # Command for Uploading the file "STOR filename"
              ftp_server.storbinary(f"STOR {filename}", file) 
            # Get list of files
            ftp_server.dir()
            # Close the Connection
            ftp_server.quit()
          #losersfile
        return 'ok'
    return render_template("mostactivefiles.html")
            #df = pd.DataFrame({'Symbol': at_, 'Name': bt_, 'Price': ct_, 'Change': dt_, 'Change %': et_, 'Volume': ft_, 'Avg volume': gt_, 'Market cap': ht_, 'Ration': it_,})
            #scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive','https://www.googleapis.com/auth/drive.file','https://www.googleapis.com/auth/spreadsheets']
            #creds = ServiceAccountCredentials.from_json_keyfile_name('service_account.json', scope)
           # client = gspread.authorize(creds)
           # spreadsheet_key = '1hVc3A_XjDt4zYwtEb5YEzQbyyjCn7LcPOQlx03dsHvs'
          #  wks_name = 'Sheet1'
          #  cell_of_start_df = 'A2'
          #  d2g.upload(df,
          #  spreadsheet_key,
          #  wks_name,
         #   credentials=creds,
         #   col_names=False,
         #   row_names=False,
         #   start_cell = cell_of_start_df,
          #  clean=False)
          #  requests.get("https://stocks.desss-portfolio.com/yahoo/most_active")
          #  return schedule.CancelJob
         #   return 'ok'
    #schedule.every(1).seconds.do(gainersdatas)
    #while True:
    #    schedule.run_pending()
    #    if not schedule.jobs:
    #        break
    #    time.sleep(1)
   # return render_template("mostactive4.html")
    #return make_response(render_template('gainers4.html'),200)
    #else:
       # return render_template("gainers4.html")

@app.route("/trendingfile", methods =["GET", "POST"])
def trendingfile():
    if request.method == "POST":
        if True:
            #url = request.form['text']
            # getting input with name = fname in HTML form
            ua = pyuser_agent.UA()
            #ua = UserAgent()
            url = request.form['namee']
            #trending = form(name = url)
            #db.session.add(trending)
            #db.session.commit()
            #url = 'https://finance.yahoo.com/gainers?count=100&offset=0'
            headers = {'User-Agent': ua.random }
            html = requests.get(url, headers=headers).content
        #html = requests.get(url).content
            soup = BeautifulSoup(html, 'lxml')

            au = soup.find_all('a', attrs={'class': 'Fw(600) C($linkColor)'})
            bu = soup.find_all('td', attrs={'aria-label': 'Name'})
            cu = soup.find_all('td', attrs={'aria-label': 'Last Price'})
            du = soup.find_all('td', attrs={'aria-label': 'Market Time'})
            eu = soup.find_all('td', attrs={'aria-label': 'Change'})
            fu = soup.find_all('td', attrs={'aria-label': '% Change'})
            gu = soup.find_all('td', attrs={'aria-label': 'Volume'})
            hu = soup.find_all('td', attrs={'aria-label': 'Market Cap'})
  

            au_ = []
            bu_ = []
            cu_ = []
            du_ = []
            eu_ = []
            fu_ = []
            gu_ = []
            hu_ = []
            for title in au:
                au_.append(title.text.strip())
            for title in bu:
                bu_.append(title.text.strip())
            for title in cu:
                cu_.append(title.text.strip())
            for title in du:
                du_.append(title.text.strip())
            for title in eu:
                eu_.append(title.text.strip())
            for title in fu:
                fu_.append(title.text.strip())
            for title in gu:
                gu_.append(title.text.strip())
            for title in hu:
                hu_.append(title.text.strip())
            dict = {'Symbol': au_, 'Name': bu_, 'Price': cu_, 'Market Time': du_, 'Change': eu_, 'Change %': fu_, 'Volume': gu_, 'Market cap': hu_}
            df = pd.DataFrame(dict)
             # saving the dataframe
            df.to_csv('yahoo_trending1.csv')
            # Fill Required Information
            HOSTNAME = "74.208.51.69"
            USERNAME = "stockftpusr"
            PASSWORD = "T11wz8w_"
            #Connect FTP Server
            ftp_server = ftplib.FTP(HOSTNAME, USERNAME, PASSWORD)
            #ftp_server.login()
            # force UTF-8 encoding
            ftp_server.encoding = "utf-8"
            #ftp_server.cwd changing required directory
            ftp_server.cwd('/assets/yahoo/yahoo_trending/')
            # Enter File Name with Extension
            filename = "yahoo_trending1.csv"
            # Read file in binary mode
            with open(filename, "rb") as file:
              # Command for Uploading the file "STOR filename"
              ftp_server.storbinary(f"STOR {filename}", file) 
            # Get list of files
            ftp_server.dir()
            # Close the Connection
            ftp_server.quit()
          #losersfile
        return 'ok'
    return render_template("trendingfiles.html") 
              # dataframe Name and Age columns
           # df = pd.DataFrame({'Symbol': au_, 'Name': bu_, 'Price': cu_, 'Market Time': du_, 'Change': eu_, 'Change %': fu_, 'Volume': gu_, 'Market cap': hu_})
           
          # scope = ['https://spreadsheets.google.com/feeds','https://www.googleapis.com/auth/drive','https://www.googleapis.com/auth/drive.file','https://www.googleapis.com/auth/spreadsheets']
           # creds = ServiceAccountCredentials.from_json_keyfile_name('yahoo_trendings.json', scope)
           # client = gspread.authorize(creds)
            #spreadsheet_key = '1FDbwLYGQHiuVALZBUcId-OggbZxdrO4CJGncd0zoY0Q'
            #wks_name = 'Sheet1'
           # cell_of_start_df = 'A2'
           # d2g.upload(df,
           # spreadsheet_key,
           # wks_name,
           # credentials=creds,
           # col_names=False,
           # row_names=False,
           # start_cell = cell_of_start_df,
           # clean=False)
           # requests.get("https://stocks.desss-portfolio.com/yahoo/yahoo_trending")
          #  return schedule.CancelJob
           # return 'ok'
    #schedule.every(1).seconds.do(gainersdatas)
    #while True:
    #    schedule.run_pending()
    #    if not schedule.jobs:
    #        break
    #    time.sleep(1)
    #return render_template("trending4.html")
    #return make_response(render_template('gainers4.html'),200)
    #else:
       # return render_template("gainers4.html")

#

app.run(host='0.0.0.0', port=8080)